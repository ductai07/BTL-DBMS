import { useState } from "react";
import Header from "../component/Header";
import Search from "../component/Search";
import Select from "../component/Select";
import Schedule from "../component/Schedule";
import { FaPlus, FaEdit, FaTrash } from "react-icons/fa";

const Showtime = () => {
  const roomOptions = [
    { key: "all", value: "--Tất cả phòng--" },
    { key: "room1", value: "Phòng 1" },
    { key: "room2", value: "Phòng 2" },
    { key: "room3", value: "Phòng 3" },
    { key: "VIP", value: "Phòng VIP" },
  ];
  const [showTimeRoom, setShowTimeRoom] = useState(() => {
    return localStorage.getItem("showTimeRoom") || roomOptions[0].value;
  });

  const statusOptions = [
    { key: "all", value: "--Tất cả trạng thái" },
    { key: "coming", value: "Sắp chiếu" },
    { key: "shown", value: "Đang chiếu" },
    { key: "showned", value: "Đã chiếu" },
  ];

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fake data for showtimes
  const [showtimes, setShowtimes] = useState([
    {
      movieName: "The Dark Knight",
      room: "Phòng 1",
      date: "2025-05-10",
      time: "19:00",
      format: "Action",
      status: "Now Showing",
      ticketsSold: 152,
    },
    {
      movieName: "Inception",
      room: "Phòng 2",
      date: "2025-05-12",
      time: "21:00",
      format: "Sci-Fi",
      status: "Coming Soon",
      ticketsSold: 148,
    },
  ]);

  const handleReset = () => {
    setEndDate("");
    setStartDate("");
    setShowTimeRoom(roomOptions[0].value);
  };

  const handleAddShowtime = (newShowtime) => {
    setShowtimes([...showtimes, newShowtime]);
    setIsModalOpen(false);
  };

  return (
    <div className="w-[100%] h-[100vh] bg-neutral-100 p-5 overflow-auto">
      <Header title={"Showtime"} />
      <div className="mb-6 bg-white p-5 shadow-md rounded-xl">
        <div className="flex gap-2 pb-4 justify-between">
          <div className="flex gap-2">
            <div>
              <div>Tên phim</div>
              <Search placeholder={"Nhập tên phim"} />
            </div>
            <div>
              <div>Phòng chiếu</div>
              <Select
                options={roomOptions}
                defaultValue={showTimeRoom}
                setDefault={setShowTimeRoom}
                keyStorage={"showTimeRoom"}
              />
            </div>
            <div>
              <div>Trạng thái</div>
              <Select
                options={statusOptions}
                defaultValue={showTimeRoom}
                setDefault={setShowTimeRoom}
                keyStorage={"showTimeRoom"}
              />
            </div>
          </div>
          <button
            className="button flex items-center gap-1"
            onClick={() => setIsModalOpen(true)}
          >
            <FaPlus />
            Showtime
          </button>
        </div>
        <div className="flex gap-2 pb-4">
          <div>
            <span>Từ ngày</span>
            <Schedule date={startDate} setDate={setStartDate} />
          </div>
          <div>
            <span>Đến ngày</span>
            <Schedule date={endDate} setDate={setEndDate} />
          </div>
        </div>
        <div className="flex gap-2 pb-4">
          <div
            className="button !bg-white !text-black border border-black flex items-center justify-center hover:cursor-pointer"
            onClick={handleReset}
          >
            Đặt lại
          </div>
          <div className="button flex items-center justify-center hover:cursor-pointer">
            Tìm kiếm
          </div>
        </div>
      </div>

      {/* Showtime Table */}
      <div className="bg-white p-5 shadow-md rounded-xl">
        <h2 className="text-lg font-bold mb-4">Danh sách Showtime</h2>
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr>
              <th className="border border-gray-300 p-2">Phim</th>
              <th className="border border-gray-300 p-2">Phòng chiếu</th>
              <th className="border border-gray-300 p-2">Ngày chiếu</th>
              <th className="border border-gray-300 p-2">Thời gian</th>
              <th className="border border-gray-300 p-2">Định dạng</th>
              <th className="border border-gray-300 p-2">Trạng thái</th>
              <th className="border border-gray-300 p-2">Vé đã bán</th>
              <th className="border border-gray-300 p-2">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {showtimes.map((showtime, index) => (
              <tr key={index}>
                <td className="border border-gray-300 p-2">
                  {showtime.movieName}
                </td>
                <td className="border border-gray-300 p-2">{showtime.room}</td>
                <td className="border border-gray-300 p-2">{showtime.date}</td>
                <td className="border border-gray-300 p-2">{showtime.time}</td>
                <td className="border border-gray-300 p-2">
                  {showtime.format}
                </td>
                <td className="border border-gray-300 p-2">
                  <span
                    className={`px-2 py-1 rounded ${
                      showtime.status === "Now Showing"
                        ? "bg-green-100 text-green-700"
                        : "bg-yellow-100 text-yellow-700"
                    }`}
                  >
                    {showtime.status}
                  </span>
                </td>
                <td className="border border-gray-300 p-2">
                  {showtime.ticketsSold}
                </td>
                <td className="border border-gray-300 p-2 flex gap-2 justify-center">
                  <button className="text-blue-500">
                    <FaEdit />
                  </button>
                  <button className="text-red-500">
                    <FaTrash />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Showtime Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-5 rounded-xl shadow-md">
            <h2 className="text-lg font-bold mb-4">Thêm Showtime</h2>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const newShowtime = {
                  movieName: formData.get("movieName"),
                  room: formData.get("room"),
                  date: formData.get("date"),
                  time: formData.get("time"),
                  format: formData.get("format"),
                  status: formData.get("status"),
                  ticketsSold: 0,
                };
                handleAddShowtime(newShowtime);
              }}
            >
              <div className="mb-4">
                <label className="block mb-2">Tên phim</label>
                <input
                  type="text"
                  name="movieName"
                  className="w-full border border-gray-300 p-2 rounded"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block mb-2">Phòng chiếu</label>
                <select
                  name="room"
                  className="w-full border border-gray-300 p-2 rounded"
                  required
                >
                  {roomOptions.map((option) => (
                    <option key={option.key} value={option.value}>
                      {option.value}
                    </option>
                  ))}
                </select>
              </div>
              <div className="mb-4">
                <label className="block mb-2">Ngày chiếu</label>
                <input
                  type="date"
                  name="date"
                  className="w-full border border-gray-300 p-2 rounded"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block mb-2">Thời gian</label>
                <input
                  type="time"
                  name="time"
                  className="w-full border border-gray-300 p-2 rounded"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block mb-2">Định dạng</label>
                <input
                  type="text"
                  name="format"
                  className="w-full border border-gray-300 p-2 rounded"
                  required
                />
              </div>
              <div className="mb-4">
                <label className="block mb-2">Trạng thái</label>
                <select
                  name="status"
                  className="w-full border border-gray-300 p-2 rounded"
                  required
                >
                  {statusOptions.map((option) => (
                    <option key={option.key} value={option.value}>
                      {option.value}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="button flex-1 bg-blue-500 text-white p-2 rounded"
                >
                  Thêm
                </button>
                <button
                  type="button"
                  className="button flex-1 bg-gray-300 p-2 rounded"
                  onClick={() => setIsModalOpen(false)}
                >
                  Hủy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Showtime;
